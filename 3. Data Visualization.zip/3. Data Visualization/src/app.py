import numpy as np
import plotly.graph_objects as go
import argparse
import os

def surface_function(x, y):
    """Define the mathematical function for the 3D surface."""
    try:
        return np.sin(np.sqrt(x**2 + y**2))
    except Exception as e:
        print(f"Error in surface function: {e}")
        raise

def generate_surface_data(x_range=(-5, 5), y_range=(-5, 5), grid_size=100):
    """Generate X, Y, Z data for the 3D surface."""
    try:
        x = np.linspace(x_range[0], x_range[1], grid_size)
        y = np.linspace(y_range[0], y_range[1], grid_size)
        X, Y = np.meshgrid(x, y)
        Z = surface_function(X, Y)
        return X, Y, Z
    except Exception as e:
        print(f"Error generating surface data: {e}")
        raise

def plot_3d_surface(X, Y, Z, save_path=None):
    """Create and display/save the 3D surface plot with a custom colorscale."""
    try:
        # Define a custom colorscale based on the provided Matplotlib code
        custom_colorscale = [
            [0.0, '#00008B'],  # Dark blue
            [0.33, '#00CED1'], # Dark turquoise
            [0.66, '#FF4500'], # Orange-red
            [1.0, '#FFD700']   # Yellow
        ]
        fig = go.Figure(data=[
            go.Surface(z=Z, x=X, y=Y, colorscale=custom_colorscale, showscale=True)
        ])
        fig.update_layout(
            title='Interactive 3D Surface Plot with Custom Colorscale',
            scene=dict(
                xaxis_title='X Axis',
                yaxis_title='Y Axis',
                zaxis_title='Z Axis'
            ),
            autosize=False,
            width=800,
            height=600
        )
        if save_path:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            fig.write_image(save_path)
            print(f"Plot saved to {save_path}")
        else:
            fig.show()
    except Exception as e:
        print(f"Error plotting surface: {e}")
        raise

def main():
    """Main function to handle command-line arguments and execute the plot."""
    parser = argparse.ArgumentParser(description="Generate an interactive 3D surface plot with Plotly.")
    parser.add_argument('--save', type=str, default=None, help='Path to save the plot (e.g., output/surface_plot.png)')
    args = parser.parse_args()
    
    try:
        X, Y, Z = generate_surface_data()
        plot_3d_surface(X, Y, Z, save_path=args.save)
    except Exception as e:
        print(f"Error in main execution: {e}")
        exit(1)

if __name__ == "__main__":
    main()